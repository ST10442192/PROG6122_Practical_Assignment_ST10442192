/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author uthandilenkosi
 */// Base class Product
import java.util.Scanner;
//QUESTION 2

// Base class Product
class Product {
    private String name;
    private double price;
    private int quantity;

    // Constructor
    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Display product information
    public void displayProduct() {
        System.out.println("Product Name: " + name + ", Price: R" + price + ", Quantity: " + quantity);
    }
}

// Derived class for Perishable products
class PerishableProduct extends Product {
    private int expirationDays;

    // Constructor
    public PerishableProduct(String name, double price, int quantity, int expirationDays) {
        super(name, price, quantity);//Calls the constructor of the product
        this.expirationDays = expirationDays;
    }

    // Display product information including expiration days
    @Override
    public void displayProduct() {
        super.displayProduct();
        System.out.println("Expiration Days: " + expirationDays);
    }
}

// Inventory Management System
class InventorySystem {
    private Product[] inventory;
    private int count;

    // Constructor
    public InventorySystem(int size) {
        inventory = new Product[size];
        count = 0;
    }

    // Add a product to inventory
    public void addProduct(Product product) {
        if (count < inventory.length) {
            inventory[count++] = product;
            System.out.println("Product added to inventory: " + product.getName());
        } else {
            System.out.println("Inventory is full. Cannot add more products.");
        }
    }

    // Display all products in inventory
    public void displayInventory() {
        System.out.println("INVENTORY REPORT :");
        System.out.println("------------------------");
        for (int i = 0; i < count; i++) {
            inventory[i].displayProduct();
            System.out.println("---------------------");
        }
    }

    // Update product quantity
    public void updateProductQuantity(String name, int newQuantity) {
        for (int i = 0; i < count; i++) {
            if (inventory[i].getName().equals(name)) {
                inventory[i].setQuantity(newQuantity);
                System.out.println("Updated quantity for " + name + " to " + newQuantity);
                return;
            }
        }
        System.out.println("Product not found.");
    }
    
    //Get the inventory array
    public Product[] getInventory() {
        return inventory;
    }
    //Get the count of products in the inventory
    public int getCount(){
        return count;
    }
}

// Main class to run the Inventory Management System with user input
public class InventoryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventorySystem inventorySystem = new InventorySystem(5);

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Display Inventory");
            System.out.println("3. Update Product Quantity");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Is this a perishable product? (yes/no): ");
                    scanner.nextLine(); // Consume newline
                    String isPerishable = scanner.nextLine();

                    if (isPerishable.equalsIgnoreCase("yes")) {
                        System.out.print("Enter expiration days: ");
                        int expirationDays = scanner.nextInt();
                        Product perishableProduct = new PerishableProduct(name, price, quantity, expirationDays);
                        inventorySystem.addProduct(perishableProduct);
                    } else {
                        Product product = new Product(name, price, quantity);
                        inventorySystem.addProduct(product);
                    }
                    break;

                case 2:
                    inventorySystem.displayInventory();
                    break;

                case 3:
                    System.out.print("Enter the name of the product to update: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter the new quantity: ");
                    int newQuantity = scanner.nextInt();
                    inventorySystem.updateProductQuantity(productName, newQuantity);
                    break;

                case 4:
                    System.out.println("Exiting Inventory Management System...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
