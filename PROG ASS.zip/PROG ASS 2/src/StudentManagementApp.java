/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author uthandilenkosi
 */
import java.util.*;
//QUESTION 1 

class Student {
    int id;
    String name; 
    int age; 
    String email;
    String course;
    
    Student(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age; 
        this.email = email; 
        this.course = course;
    }
    
    
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Email: " + email + ", Course: " + course; 
    }

    // Methods as per the requirements
    public static void saveStudent(Scanner input, ArrayList<Student> students) {
        System.out.println("Enter student ID: ");
        int studentId = Integer.parseInt(input.nextLine());
       
        System.out.println("Enter student name:");
        String studentName = input.nextLine();
        
        int studentAge = getValidStudentAge(input);
        
        System.out.println("Enter student email:");
        String studentEmail = input.nextLine();
        
        System.out.println("Enter student course:");
        String studentCourse = input.nextLine();
        
        Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        students.add(student);
        System.out.println("Student " + studentName + " captured successfully.");
    }

    private static int getValidStudentAge(Scanner input) {
        int age;
        
        while(true) {
            System.out.println("Enter student age: ");
            String inputAge = input.nextLine();
       
           
            //CODE ATTRIBUTUION
            //This method was taken from:
            //https://stackoverflow.com/a/19925109
            //BackSlash
            //https://stackoverflow.com/users/1759845/backslash
            
            
            try { 
                age = Integer.parseInt(inputAge);
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("Invalid age. Student age must be 16 or older.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a numeric age.");
            }
        }
        return age;
    }

    public static void searchStudent(Scanner input, ArrayList<Student> students) {
    System.out.println("Enter the student id to search:");
    int studentId = Integer.parseInt(input.nextLine());

    System.out.println("---------------------------------------------");
    boolean found = false;
    for (Student student : students) {
        if (student.id == studentId) {
            System.out.println("STUDENT ID: " + student.id);
            System.out.println("STUDENT NAME: " + student.name);
            System.out.println("STUDENT AGE: " + student.age);
            System.out.println("STUDENT EMAIL: " + student.email);
            System.out.println("STUDENT COURSE: " + student.course);
            found = true;
            break;
        }
    }

    if (!found) {
        System.out.println("Student with Student Id: " + studentId + " was not found!");
    }
    System.out.println("---------------------------------------------");
    System.out.println("Enter (1) to launch menu or any other key to exit");
    
    String choice = input.nextLine();
    if (!choice.equals("1")) {
        exitStudentApplication();
    }
}


    public static void deleteStudent(Scanner input, ArrayList<Student> students) {
        System.out.println("Enter student ID to delete:");
        int studentId = Integer.parseInt(input.nextLine());

        for(Student student : students) {
            if (student.id == studentId) {
                System.out.println("Are you sure you want to delete student " + studentId + "? Yes (y) to delete.");
                
                //CODE ATTRIBUTON. 
                //This method is taken from: 
                //https://codegym.cc/groups/posts/string-equalsignorecase-method-in-java
                //Oleksandr Miadelets
                
                String confirmation = input.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student with Student ID: " + studentId + " was deleted!");
                } else {
                    System.out.println("Deletion canceled.");
                }
                return;
            }
        }
        System.out.println("Student with Student ID: " + studentId + " not found.");
    }

    public static void studentReport(ArrayList<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No students captured yet.");
        } else {
            int studentNumber = 1;
            for (Student student : students) {
                System.out.println("STUDENT " + studentNumber);
                System.out.println("---------------------------------------------");
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                System.out.println("---------------------------------------------");
                studentNumber++;
            }
        }
    }

    public static void exitStudentApplication() {
        System.out.println("Exiting application...");
        System.exit(0);
    }
}

// Main class to run the application
public class StudentManagementApp {
    private static ArrayList<Student> students = new ArrayList<>();
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("***************************************");
            System.out.println("Please select one of the following");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit application.");
            
            String choice = input.nextLine();
            
            switch(choice) {
                case "1":
                    Student.saveStudent(input, students);
                    break;
                    
                case "2":
                    Student.searchStudent(input, students);
                    break;
                    
                case "3":
                    Student.deleteStudent(input, students);
                    break;
                  
                case "4":
                    Student.studentReport(students);
                    break;
                    
                case "5":
                    Student.exitStudentApplication();
                    break;
                    
                default:
                    System.out.println("Invalid choice! Please enter a valid option.");
                    break;
            }
        }
    }
}

