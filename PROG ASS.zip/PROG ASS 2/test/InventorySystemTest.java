/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class InventorySystemTest {
    
    private InventorySystem inventorySystem;
    private Product product;
    private PerishableProduct perishableProduct;

    @Before
    public void setUp() {
        inventorySystem = new InventorySystem(3);
        product = new Product("Soap", 2.5, 10);
        perishableProduct = new PerishableProduct("Milk", 1.5, 20, 5);
    }

    @Test
    public void testAddProduct() {
        inventorySystem.addProduct(product);
        assertEquals("Soap", inventorySystem.getInventory()[0].getName());
        assertEquals(1, inventorySystem.getCount());

        inventorySystem.addProduct(perishableProduct);
        assertEquals("Milk", inventorySystem.getInventory()[1].getName());
        assertEquals(2, inventorySystem.getCount());
    }

    @Test
    public void testUpdateProductQuantity() {
        inventorySystem.addProduct(product);
        inventorySystem.updateProductQuantity("Soap", 15);
        assertEquals(15, inventorySystem.getInventory()[0].getQuantity());
    }

    @Test
    public void testDisplayProduct() {
        inventorySystem.addProduct(product);
        inventorySystem.addProduct(perishableProduct);

      //  assertEquals("Product Name: Soap, Price: $2.5, Quantity: 10", inventorySystem.getInventory()[0].displayProduct());
      //  assertEquals("Product Name: Milk, Price: $1.5, Quantity: 20\nExpiration Days: 5", inventorySystem.getInventory()[1].displayProduct());
    }

    @Test
    public void testInventoryFull() {
        inventorySystem.addProduct(product);
        inventorySystem.addProduct(perishableProduct);
        inventorySystem.addProduct(new Product("Shampoo", 5.0, 5));
        
        // This should print a message that the inventory is full and not add the product.
        inventorySystem.addProduct(new Product("Conditioner", 4.0, 3));
        assertEquals(3, inventorySystem.getCount());  // Inventory should still have only 3 products.
    }

    @Test
    public void testUpdateNonExistingProduct() {
        inventorySystem.addProduct(product);
        inventorySystem.updateProductQuantity("NonExisting", 50); // This should not change any product quantity
        assertEquals(10, inventorySystem.getInventory()[0].getQuantity());
    }
}
