/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author uthandilenkosi
 */


public class StudentManagementAppTest {

    @Before
    public void setUp() {
        // Ensure the students list is cleared before each test
        StudentManagementApp.students = new ArrayList<>();
    }

    @Test
    public void TestSaveStudent() {
        // Mock user input
        String input = "1\nJohn Doe\n20\njohndoe@example.com\nComputer Science";
        Scanner scanner = new Scanner(input);

        // Call the captureStudent method
        StudentManagementApp.captureStudent(scanner);

        // Validate the student was added correctly
        assertEquals(1, StudentManagementApp.students.size());
        Student savedStudent = StudentManagementApp.students.get(0);
        assertEquals(1, savedStudent.id);
        assertEquals("John Doe", savedStudent.name);
        assertEquals(20, savedStudent.age);
        assertEquals("johndoe@example.com", savedStudent.email);
        assertEquals("Computer Science", savedStudent.course);
    }

    @Test
    public void TestSearchStudent() {
        // Add a student to search for
        Student student = new Student(1, "John Doe", 20, "johndoe@example.com", "Computer Science");
        StudentManagementApp.students.add(student);

        // Mock user input for searching
        String input = "1";
        Scanner scanner = new Scanner(input);

        // Simulate searching for the student
        StudentManagementApp.searchStudent(scanner);

        // Since we do not have a return, we assume the printout happens correctly.
        // For thorough testing, we'd inspect the console output, which is generally not done in unit tests.
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        // Mock user input for searching
        String input = "999"; // Non-existent student ID
        Scanner scanner = new Scanner(input);

        // Simulate searching for the student
        StudentManagementApp.searchStudent(scanner);

        // Since there is no return, this would test the console output.
        // For thorough testing, inspect console output, which is generally not covered in basic unit tests.
    }

    @Test
    public void TestDeleteStudent() {
        // Add a student to delete
        Student student = new Student(1, "John Doe", 20, "johndoe@example.com", "Computer Science");
        StudentManagementApp.students.add(student);

        // Mock user input for deleting
        String input = "1\ny"; // Student ID 1 and confirmation 'y'
        Scanner scanner = new Scanner(input);

        // Call the deleteStudent method
        StudentManagementApp.deleteStudent(scanner);

        // Validate the student was deleted correctly
        assertEquals(0, StudentManagementApp.students.size());
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        // Mock user input for deleting
        String input = "999"; // Non-existent student ID
        Scanner scanner = new Scanner(input);

        // Call the deleteStudent method
        StudentManagementApp.deleteStudent(scanner);

        // Validate that no students were deleted
        assertEquals(0, StudentManagementApp.students.size());
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Mock user input
        String input = "20"; // Valid age
        Scanner scanner = new Scanner(input);

        // Call the method to validate age
        int age = StudentManagementApp.getValidStudentAge(scanner);

        // Check that the valid age is accepted
        assertEquals(20, age);
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Mock user input
        String input = "15\n16"; // Invalid age first, then valid age
        Scanner scanner = new Scanner(input);

        // Call the method to validate age
        int age = StudentManagementApp.getValidStudentAge(scanner);

        // Check that the first invalid age is rejected and the valid age is accepted
        assertEquals(16, age);
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Mock user input
        String input = "abc\n20"; // Invalid character first, then valid age
        Scanner scanner = new Scanner(input);

        // Call the method to validate age
        int age = StudentManagementApp.getValidStudentAge(scanner);

        // Check that the valid age is accepted after an invalid input
        assertEquals(20, age);
    }
}
